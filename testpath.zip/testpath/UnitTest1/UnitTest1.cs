﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.UserManagement;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Security.ConsoleTest;
using DigiOPS.TechFoundation.Security;
using System.IO;
using System.Xml;


namespace UnitTest1
{
    [TestClass]
    public class UnitTest1
    {


        [TestMethod]
        public void assignrole()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            objRoleInfo.LoginId = "suji";
            BaseCustomUserManagement base1 = new BaseCustomUserManagement();
            int n = base1.AssignUserRole(objRoleInfo);

            Assert.AreEqual(n, 0);
        }

        //------------------------------------------------------------------------------

        //USER MANAGEMNT

        [TestMethod]
        public void USERcreateUserNegative()
        {

            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.CreateUser(objRoleInfo);
            
            Assert.IsTrue(n<=0);
            
        }

        [TestMethod]
        public void USERcreateUserPositive()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.CreateUser(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void USERcreateUserException()
        {
        try{
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "sdfadfafafafdf";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.CreateUser(objRoleInfo);

           
            throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch(Exception ex)
            {
                //Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }

        [TestMethod]
        public void USERupdateUserPositive()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.UpdateUser(objRoleInfo);

            Assert.IsTrue(n > 0);

        }
        [TestMethod]
        public void USERupdateUserNegative()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "2325425";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.UpdateUser(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }


        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void USERupdateUserException()
        {
            try
            {
                UserInfo objRoleInfo = new UserInfo();
                objRoleInfo.AppID = "EMT";
                //objRoleInfo.CountryId = "2";
                //objRoleInfo.UserID = "572814";
                objRoleInfo.RoleId = 2;
                //objRoleInfo.LoginId = "suji";
                objRoleInfo.UserID = "577373";
                objRoleInfo.FirstName = "Vigneshwar";
                objRoleInfo.LastName = "Selvaraj";
                objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
                objRoleInfo.EncryptPassword = "asjdfasdfugasd";
                objRoleInfo.EncryptConfirmPassword = "sdfadfafafafdf";
                objRoleInfo.TimeZone = "India";
                objRoleInfo.IsActive = false;
                //objRoleInfo.UserManagingType="";
                objRoleInfo.LoginType = "Admin";
                //objRoleInfo.RoleId = 1;
                //objRoleInfo.UTCTime = "";
                UserManagementFactory userfactory = new UserManagementFactory();
                var userhandler = userfactory.GetUserManagementHandler("User");
                int n = userhandler.UpdateUser(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch (Exception ex)
            {
                //Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }

        [TestMethod]
        public void USERassignUserRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji"; 

            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.AssignUserRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }
        [TestMethod]
        public void USERassignUserRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            //objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "234234";
            ///objRoleInfo.RoleId = 1;
            //objRoleInfo.LoginId = "suji";

            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.AssignUserRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void USERassignUserRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                UserManagementFactory userfactory = new UserManagementFactory();
                var userhandler = userfactory.GetUserManagementHandler("User");
                int n = userhandler.AssignUserRole(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch 
            {
               // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }


        [TestMethod]
        public void USERupdateUserRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.UpdateUserRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        public void USERupdateUserRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.UpdateUserRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }


        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void USERupdateUserRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                objRoleInfo.UserRoleMapId = "";
                UserManagementFactory userfactory = new UserManagementFactory();
                var userhandler = userfactory.GetUserManagementHandler("User");
                int n = userhandler.UpdateUserRole(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch
            {
                // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }


        [TestMethod]
        public void USERdeleteUserRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.DeleteUserRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }

        [TestMethod]
        public void USERdeleteUserRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.DeleteUserRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void USERdeleteUserRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                objRoleInfo.UserRoleMapId = "";
                UserManagementFactory userfactory = new UserManagementFactory();
                var userhandler = userfactory.GetUserManagementHandler("User");
                int n = userhandler.DeleteUserRole(objRoleInfo);
                 

                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch
            {
                // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }

        //------------------------------------------------------------------------------

        //DATA ACCESS LAYER


        [TestMethod]
        public void DATAcreateNegative()
        {

            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n=objUserRepository.Create(objRoleInfo);
            //int n = userhandler.CreateUser(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }

        [TestMethod]
        public void DATAcreatePositive()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Create(objRoleInfo);
            //int n = userhandler.CreateUser(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DATAcreateException()
        {
            try
            {
                UserInfo objRoleInfo = new UserInfo();
                objRoleInfo.AppID = "EMT";
                //objRoleInfo.CountryId = "2";
                //objRoleInfo.UserID = "572814";
                objRoleInfo.RoleId = 2;
                //objRoleInfo.LoginId = "suji";
                objRoleInfo.UserID = "577373";
                objRoleInfo.FirstName = "Vigneshwar";
                objRoleInfo.LastName = "Selvaraj";
                objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
                objRoleInfo.EncryptPassword = "asjdfasdfugasd";
                objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
                objRoleInfo.TimeZone = "India";
                objRoleInfo.IsActive = false;
                //objRoleInfo.UserManagingType="";
                objRoleInfo.LoginType = "Admin";
                //objRoleInfo.RoleId = 1;
                //objRoleInfo.UTCTime = "";
                EMTUserRepository objUserRepository = new EMTUserRepository();
                int n = objUserRepository.Create(objRoleInfo);
                //int n = userhandler.CreateUser(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch (Exception ex)
            {
                //Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }

        [TestMethod]
        public void DATAupdatePositive()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Update(objRoleInfo);

            Assert.IsTrue(n > 0);

        }
        [TestMethod]
        public void DATAupdateNegative()
        {
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Update(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }


        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DATAupdateException()
        {
            try
            {
                UserInfo objRoleInfo = new UserInfo();
                objRoleInfo.AppID = "EMT";
                //objRoleInfo.CountryId = "2";
                //objRoleInfo.UserID = "572814";
                objRoleInfo.RoleId = 2;
                //objRoleInfo.LoginId = "suji";
                objRoleInfo.UserID = "577373";
                objRoleInfo.FirstName = "Vigneshwar";
                objRoleInfo.LastName = "Selvaraj";
                objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
                objRoleInfo.EncryptPassword = "asjdfasdfugasd";
                objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
                objRoleInfo.TimeZone = "India";
                objRoleInfo.IsActive = false;
                //objRoleInfo.UserManagingType="";
                objRoleInfo.LoginType = "Admin";
                //objRoleInfo.RoleId = 1;
                //objRoleInfo.UTCTime = "";
                EMTUserRepository objUserRepository = new EMTUserRepository();
                int n = objUserRepository.Update(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch (Exception ex)
            {
                //Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }

        [TestMethod]
        public void DATAassignRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";

            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.AssignRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }
        [TestMethod]
        public void DATAassignRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            //objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "234234";
            ///objRoleInfo.RoleId = 1;
            //objRoleInfo.LoginId = "suji";

            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.AssignRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DATAassignRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                EMTUserRepository objUserRepository = new EMTUserRepository();
                int n = objUserRepository.AssignRole(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch
            {
                // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }


        [TestMethod]
        public void DATAupdateRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.UpdateUserRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        public void DATAupdateRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.UpdateUserRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }


        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DATAupdateRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                objRoleInfo.UserRoleMapId = "";
                EMTUserRepository objUserRepository = new EMTUserRepository();
                int n = objUserRepository.UpdateUserRole(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch
            {
                // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }


        [TestMethod]
        public void DATAdeleteRoleNegative()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);

            Assert.IsTrue(n <= 0);

        }

        [TestMethod]
        public void DATAdeleteRolePositive()
        {
            RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "234234";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);

            Assert.IsTrue(n > 0);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DATAdeleteRoleException()
        {
            try
            {
                RoleInfo objRoleInfo = new RoleInfo();
                objRoleInfo.AppID = "EMT";
                objRoleInfo.CountryId = "2";
                objRoleInfo.UserID = "234234";
                objRoleInfo.RoleId = 1;
                objRoleInfo.LoginId = "suji";
                objRoleInfo.UserRoleMapId = "";
                EMTUserRepository objUserRepository = new EMTUserRepository();
                int n = objUserRepository.DeleteUserRole(objRoleInfo);


                throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
            }
            catch
            {
                // Assert.AreEqual("Password's do not match.", ex.Message);
                throw;

            }
        }






        //---------------------------------------------------------------------------------

        [TestMethod]
        public void expotHtmlpositive()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }

            Assert.IsTrue(File.Exists(dataTransferInfo.DestinationExcelFilePath));

        }

        [TestMethod]
        public void expotHtmlpositive2()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            string testData = System.IO.File.ReadAllText(@"D:\\test\\blank.html");

            Assert.IsNotNull(testData);
        }


        [TestMethod]
        public void expotHtmlnegative()
        {
            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = null;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);


            string testData = System.IO.File.ReadAllText(@"D:\\test\\blank.html");
            bool n= true;
            if(string.IsNullOrEmpty(testData))
            {
               n=false;
            }
            Assert.IsFalse(n);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void exporthtmlexception()
        {
            try
            {

                //DataTable dataTable = new DataTable();
                //dataTable.Columns.Add("AssociateID");
                //DataRow oneRow = dataTable.NewRow();
                //oneRow["AssociateID"] = "454545";
                //dataTable.Rows.Add(oneRow);

                DataTransferInfo dataTransferInfo = new DataTransferInfo();
                dataTransferInfo.ExcelExportType = "Html";
                //dataTransferInfo.ExcelExportType = "OleDB";
                dataTransferInfo.DataTable = null;
                dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
                //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
                //dataTransferInfo.ExcelSheetName = "TestSheetName";

                DataTransferFactory dataTransferFactory = new DataTransferFactory();
                var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
                dataTransferExcel.Export(dataTransferInfo);

                throw new System.Exception(dataTransferInfo.ErrorMessage.ToString());
            }
            catch(Exception ex)
            {
                Assert.AreEqual("WriteToHtmlFormatExcel :: dtExcelData is null", ex.Message);
                throw;
            }
            

            //string errorMessage = "";
           // if (dataTransferInfo.ErrorMessage != null)
           // {
           //     errorMessage = dataTransferInfo.ErrorMessage.ToString();
          //  }
            
            



        }
       /* [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Withdraw_AmountMoreThanBalance_Throws()
        {
            // arrange  
            int n = 2000;
            // act 
            Program.Withdraw(n);
            // assert is handled by the ExpectedException  
        }  */

         [TestMethod]
         [ExpectedException(typeof(ArgumentException))]
        public void AESEncryptsException()
        {
            CryptInfo new1 = new CryptInfo();
            new1.ValueToCrypt = "cogni";
            new1.CryptKey =null;
            AESCrypt obj1 = new AESCrypt();
            try
            {
                string result = obj1.Encrypt(new1);
            }
             catch
            {
                 //Assert.AreEqual("Invalid TamperProofString",ex.Message);
                 throw;
            }

        }


    }
}
