﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Logging
{
   public interface ICustomLogger
    {
       void LogInfo(LogInfo loginfo);

       void LogDebug(Object logdebug);

       void LogDebug(Object logdebug, Exception ex);

       void LogException(Exception ex);
    }
}
