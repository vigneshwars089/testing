﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Logging
{
    public class BaseCustomLogger : ICustomLogger
    {
        public virtual void LogInfo(LogInfo loginfo)
        {
           
        }
        public virtual void LogException(Exception ex)
        {
           
        }


        public virtual void LogDebug(object logdebug)
        {
           
        }

        public virtual void LogDebug(object logdebug, Exception ex)
        {
           
        }

      
    }
}
