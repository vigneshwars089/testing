﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
   public class DataTransferFactory : IDataTransferFactory
    {
       public ICustomDataTransfer GetDataTransferHandler(string loggerType)
       {
           switch (loggerType)
           {
               case S_DataTransferPDFTypes.PDF:
                   return new PDFDataTransfer();

               case S_DataTransferExcelTypes.Excel:
                   return new ExcelDataTransfer();                  

               default:
                   return new BaseDataTransfer();
           }
       }
    }
}
