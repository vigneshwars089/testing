﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class UserRepository : IUserRepository
    {

        public virtual int Create(UserInfo objUserInfo)
        {
            return 0;
        }

        public virtual int Read(UserInfo objUserInfo)
        {
            return 0;
        }

        public virtual int Update(UserInfo objUserInfo)
        {
            return 0;
        }

        public virtual int Delete(UserInfo objUserInfo)
        {
            return 0;
        }


        public string ConnectionString
        {
            get; set;  }


        public virtual bool ValidateCredentials(UserInfo objUserInfo)
        {
            return false;
        }


        public virtual int AssignRole(RoleInfo objUserInfo)
        {
            return 0;
        }

        public virtual int UpdateUserRole(RoleInfo objUserInfo)
        {
            return 0;
        }

        public virtual int DeleteUserRole(RoleInfo objRoleInfo)
        {
            return 0;
        }
    }
}
