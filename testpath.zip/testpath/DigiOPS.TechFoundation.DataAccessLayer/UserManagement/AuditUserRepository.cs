﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AuditUserRepository : UserRepository
    {
        public override int Create(UserInfo objUserInfo)
        {
            return 0;
        }

        public override int Read(UserInfo objUserInfo)
        {
            return 0;
        }

        public override int Update(UserInfo objUserInfo)
        {
            return 0;
        }

        public override int Delete(UserInfo objUserInfo)
        {
            return 0;
        }
    }
}
