﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using DigiOPS.TechFoundation.RuleEngine;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class EMTUserRepository : UserRepository
    {
        public override int Create(UserInfo objUserInfo)
        {
                 
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@USERID", objUserInfo.UserID);
                hs.Add("@FIRSTNAME", objUserInfo.FirstName);
                hs.Add("@LASTNAME", objUserInfo.LastName);
                hs.Add("@EMAIL", objUserInfo.EmailID);
                hs.Add("@Password",objUserInfo.EncryptPassword);
                hs.Add("@ISACTIVE",objUserInfo.IsActive);
                hs.Add("@LoggedinUserId",objUserInfo.RoleId);
                hs.Add("@TIMEZONE", objUserInfo.TimeZone);
                hs.Add("@OFFSET", objUserInfo.UTCTime);
            }
            catch (Exception ex)
            {
               // logger.HandleError(ex, UserData.UserId, " | UserManagementDataService.cs | AddUser()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.CREATE_USERS, hs));
           
          
        }

        public override int Read(UserInfo objUserInfo)
        {
            return 0;
        }

        public override int Update(UserInfo objUserInfo)
        {
             Hashtable hs = new Hashtable();
            try{
             hs.Add("@USERID", objUserInfo.UserID);
                hs.Add("@FIRSTNAME", objUserInfo.FirstName);
                hs.Add("@LASTNAME", objUserInfo.LastName);
                hs.Add("@EMAIL", objUserInfo.EmailID);
                hs.Add("@Password",objUserInfo.EncryptPassword);
                hs.Add("@ISACTIVE",objUserInfo.IsActive);
                hs.Add("@LoggedinUserId",objUserInfo.RoleId);
                hs.Add("@TIMEZONE", objUserInfo.TimeZone);
                hs.Add("@OFFSET", objUserInfo.UTCTime);}
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateUser()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.UPDATE_USERS, hs));
        }

        public override int Delete(UserInfo objUserInfo)
        {
            return 0;
        }

        public override int AssignRole(RoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", objRoleInfo.UserID);
                hs.Add("@RoleId", objRoleInfo.RoleId);
                hs.Add("@LoggedinUserId", objRoleInfo.LoginId);
                hs.Add("@CountryIdsToMap", objRoleInfo.CountryId);
            }
            catch (Exception ex)
            {
                // errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | MapUserRole()");

            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.CreateRoleMap, hs));
        }

        public override int UpdateUserRole(RoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserRoleMappingId", objRoleInfo.UserRoleMapId);
                //hs.Add("@UserID", UserId);
                //hs.Add("@RoleId", RoleId);
                hs.Add("@CountryIdsToMap", objRoleInfo.CountryId);
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateRoleMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.UpdateRoleMap, hs));
        }
        public override int DeleteUserRole(RoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserRoleMappingId", objRoleInfo.UserRoleMapId);
            }
            catch (Exception ex)
            {
                // errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteRoleMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.DeleteRoleMap, hs));
        }

        public override bool ValidateCredentials(UserInfo objUserInfo)
        {
            return false;
        }

    }
}
