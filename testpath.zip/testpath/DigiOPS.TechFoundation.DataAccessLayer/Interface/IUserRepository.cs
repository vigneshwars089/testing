﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IUserRepository
    {
        int Create(UserInfo objUserInfo);
        int Read(UserInfo objUserInfo);
        int Update(UserInfo objUserInfo);
        int Delete(UserInfo objUserInfo);
        string ConnectionString { get; set; }
        bool ValidateCredentials(UserInfo objUserInfo);
         int AssignRole(RoleInfo objUserInfo);
        int UpdateUserRole(RoleInfo objUserInfo);
        int DeleteUserRole(RoleInfo objRoleInfo);
        
    }
}
