﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Newtonsoft.Json;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.DataTransfer;
using System.Data;
using System.Data.OleDb;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.UserManagement;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.IO;

namespace DigiOPS.TechFoundation.Security.ConsoleTest
{
 /// <summary>
 /// 
 /// </summary>
    public class Program
    {
        public static void Main(string[] args)
        {
            /*
            //User Authentication
            UserContextInfo userContextInfo = new UserContextInfo();
            userContextInfo.UserID = "587767";
            userContextInfo.Password = "My password";
            userContextInfo.Domain = "CTS";
            var securityFactory = new SecurityFactory();
            bool isAuthenticated = securityFactory.GetUserSecurityHandler("AD").Authenticate(userContextInfo);

            bool copyOfIsAuthenticated = isAuthenticated;

            //Encryption/Decryption
            CryptInfo cryptInfo = new CryptInfo();
            cryptInfo.CryptKey = "123";
            cryptInfo.ValueToCrypt = "Cognizant";
            string encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            cryptInfo.ValueToCrypt = encryptedValue;
            string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);

            string copyOfTheDecryptedValue = decryptedValue;

            //ParseUserToken
            var securityHandler = securityFactory.GetUserSecurityHandler("AD");
            string jsonWebToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOiI1OTk4MzUiLCJDcmVhdGVkRGF0ZVRpbWUiOiIyLzEzLzIwMTcgNDoyNjo0NiBQTSJ9.ZRamafCH37HAWoZlPIBoQLdt_z9iuznx9vnVP1YiYtw";
            string secretKey = "YOUR_CLIENT_SECRET";
            securityHandler.UserTimeStampCheck(jsonWebToken, secretKey, userContextInfo);

            string userID = userContextInfo.UserID;
            string copyOfUserID = userID;
            DateTime createdOn = userContextInfo.CreatedOn;
            DateTime copyOfCreatedOn = createdOn;
            bool resultStatus = userContextInfo.ResultStatus;
            bool copyOfResultStatus = resultStatus;
             * */


            /*DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.InputExcelFilePath = @"D:\test\new.xlsx";
            dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Import(dataTransferInfo);
            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }
            int thisManyRows = dataTransferInfo.DataTable.Rows.Count;

            Console.WriteLine(dataTransferInfo.DataTable);
            Console.ReadLine();*/


            //DataTable dataTable = new DataTable();
            //dataTable.Columns.Add("AssociateID");
            //DataRow oneRow = dataTable.NewRow();
            //oneRow["AssociateID"] = "454545";
            //dataTable.Rows.Add(oneRow);

            /*DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = null;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }
            Console.WriteLine(errorMessage);
            Console.ReadLine();*/





            /*DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = null;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);
            
            if(File.Exists(dataTransferInfo.DestinationExcelFilePath))
            {
                Console.WriteLine("True");
                Console.ReadLine();
            }
            string testData = System.IO.File.ReadAllText(@"D:\\test\\blank.html");
            //Console.WriteLine(testData);
            if (string.IsNullOrEmpty(testData))
            {
                Console.WriteLine("True");
                Console.ReadLine();
            }*/


              /*DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.InputExcelFilePath = @"D:\\test\\book6.xlsx";
            dataTransferInfo.ExcelSheetName = "Sheet1";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Import(dataTransferInfo);
         Console.WriteLine(dataTransferInfo.DataTable.Rows.Count);  
        foreach (DataRow dataRow in dataTransferInfo.DataTable.Rows)
      {
       foreach (var item in dataRow.ItemArray)
       {
        Console.WriteLine(item);
       }
      }
        Console.ReadLine();*/


          /*  UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.CreateUser(objRoleInfo);
            string errorMessage = "true";
            if (objRoleInfo.ErrorMessage!=null)
            {
              errorMessage = objRoleInfo.ErrorMessage.ToString();
            }
            Console.WriteLine(errorMessage);
            Console.ReadLine(); */

            /*RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 1;
            objRoleInfo.LoginId = "suji";

            UserManagementFactory userfactory = new UserManagementFactory();
            var userhandler = userfactory.GetUserManagementHandler("User");
            int n = userhandler.AssignUserRole(objRoleInfo);
            Console.WriteLine(n);
                        Console.ReadLine(); 
            */


            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.AppID = "EMT";
            //objRoleInfo.CountryId = "2";
            //objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            //objRoleInfo.LoginId = "suji";
            objRoleInfo.UserID = "577373";
            objRoleInfo.FirstName = "Vigneshwar";
            objRoleInfo.LastName = "Selvaraj";
            objRoleInfo.EmailID = "Vigneshwar.Selvaraj@cognizant.com";
            objRoleInfo.EncryptPassword = "asjdfasdfugasd";
            objRoleInfo.EncryptConfirmPassword = "asjdfasdfugasd";
            objRoleInfo.TimeZone = "India";
            objRoleInfo.IsActive = false;
            //objRoleInfo.UserManagingType="";
            objRoleInfo.LoginType = "Admin";
            //objRoleInfo.RoleId = 1;
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            objUserRepository.Create(objRoleInfo);




            /*RoleInfo objRoleInfo = new RoleInfo();
            objRoleInfo.AppID = "EMT";
            objRoleInfo.CountryId = "2";
            objRoleInfo.UserID = "572814";
            objRoleInfo.RoleId = 2;
            objRoleInfo.LoginId = "suji";
            BaseCustomUserManagement base1 = new BaseCustomUserManagement();
            int n = base1.AssignUserRole(objRoleInfo);*/
           


        }
        /*public static void Withdraw(int amount)
        {
            int m_balance = 1000;
            if (m_balance >= amount)
            {
                m_balance -= amount;
            }
            else
            {
                throw new ArgumentException("Withdrawal exceeds balance!");
            }
        }  */









    }
}
