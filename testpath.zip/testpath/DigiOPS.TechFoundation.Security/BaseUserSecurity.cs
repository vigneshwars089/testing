﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Security
{
    public class BaseUserSecurity : IUserSecurity
    {
        protected ResponseInfo ValidateUserContext(UserContextInfo objUserContextInfo)
	{
        ResponseInfo objResponseInfo = new ResponseInfo { ResultStatus = false };
        if (string.IsNullOrEmpty(objUserContextInfo.UserID.Trim()))
        {
            objUserContextInfo.ErrorMessage.Append("Username is null or empty. ");
            return objResponseInfo;
        }
        if (string.IsNullOrEmpty(objUserContextInfo.Password.Trim()))
        {
            objUserContextInfo.ErrorMessage.Append("Password is null or empty. ");
            return objResponseInfo;
        }
        if (string.IsNullOrEmpty(objUserContextInfo.Domain.Trim()))
        {
            objUserContextInfo.ErrorMessage.Append("Domain is null or empty. ");
            return objResponseInfo;
        }

        return new ResponseInfo { ResultStatus = true };
	}

        public virtual bool Authenticate(UserContextInfo objUserContextInfo)
        {
            return false;
        }
        public virtual bool Authorize(UserRoleInfo objUserRoleInfo)
        {
            return false;
        }




        public bool UserTimeStampCheck(string jsonWebToken, string secretKey, UserContextInfo userContextInfo)
        {
            UserContextInfo objUserContextInfo = new UserContextInfo();
           
            try
            {
                byte[] secretKeyBytes = Encoding.ASCII.GetBytes(secretKey);
                string decodedToken = Jose.JWT.Decode(jsonWebToken, secretKeyBytes);
                JsonToken data = JsonConvert.DeserializeObject<JsonToken>(decodedToken);
                userContextInfo.UserID = data.UserID;
                userContextInfo.CreatedOn = data.CreatedDateTime;
                userContextInfo.ResultStatus = true;
            }
            catch (Exception ex)
            {
                userContextInfo.ErrorMessage.Append(ex.Message);
            }
            return userContextInfo.ResultStatus;
        }
    }

    public class JsonToken
    {
        public string UserID { get; set; }
        public DateTime CreatedDateTime { get; set; }
    }
   
}
