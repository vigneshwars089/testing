﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class DBUserSecurity : BaseUserSecurity
    {
     
   /// <summary>
   /// DB Method to Authenticate user
   /// </summary>
        /// <param name="objUserContextInfo">User Credentials</param>
   /// <returns>bool</returns>
        public override bool Authenticate(UserContextInfo objUserContextInfo)
        {
            return false;
            //if(ValidateUserContext(objUserContextInfo).ResultStatus)
            //       {
            //           DBSecurityHandler objDBSecurityHandler = new DBSecurityHandler();
            //    bool ResultobjDBSecurityHandler= objDBSecurityHandler.DBSecurityHandlerAuthorize(objUserContextInfo);
            //to your logic here
            //Hashtable hs = new Hashtable();
            //hs.Add("@UserID", objUserContextInfo.UserID.Trim());
            //if(!string.IsNullOrEmpty( objUserContextInfo.Password.Trim()))
            //    hs.Add("@Password", objUserContextInfo.Password.Trim());

       //    return Convert.ToInt32(this.SelectSingleValue("USP_USERLOGIN", hs));
            // Convert.ToInt32(this.SelectSingleValue("USP_VALIDATEUSERID", hs));
            //    return ResultobjDBSecurityHandler;
            //       }
            //else
            //    return objUserContextInfo.ResultStatus = false;
        }
        public override bool Authorize(UserRoleInfo objUserRoleInfo)
        {
            //to your logic here
            return false;
        }
       

    }
}
