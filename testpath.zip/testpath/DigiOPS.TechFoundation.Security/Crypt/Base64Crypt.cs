﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class Base64Crypt : BaseCrypt
    {
        public override string Encrypt(CryptInfo objCryptInfo)
        {
            return Encode(objCryptInfo.ValueToCrypt);

        }
        public override string Decrypt(CryptInfo objCryptInfo)
        {
            return Decode(objCryptInfo.ValueToCrypt);

        }
        public static string Encode(string value)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(value);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        /// <summary>
        /// Method to Decrypt a string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string Decode(string value)
        {
            byte[] b = Convert.FromBase64String(value.ToString());
            string decryptedvalue = System.Text.ASCIIEncoding.ASCII.GetString(b);
            return decryptedvalue;
        }
    }
}
