﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class RSACrypt: BaseCrypt
    {

        public override string Encrypt(CryptInfo objCryptInfo)
        {
            return null;
        }
        public override string Decrypt(CryptInfo objCryptInfo)
        {
            return null;
        }
    }
   
   
}
