﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class ProductLicenseKey : BaseProductLicenseKey
    {
        string cryptKey = "ProductKeyInformation";
        /// <summary>
        /// AD Method to Authenticate user
        /// </summary>
        /// <param name="objUserContextInfo">User Credentials</param>
        /// <returns>bool</returns>
        public override string GenerateProductKey(LicenseInfo productKeyInfo)
        {
            try
            {
                productKeyInfo.ErrorMessage = new StringBuilder();
                string productKey = productKeyInfo.ToolPurchased + "|" + productKeyInfo.DateOfPurchase + "|" + productKeyInfo.Version + "|" + productKeyInfo.InstanceID + "|" + productKeyInfo.UserCount;
               // ResponseInfo responseInfo = ValidateProductKeyInfo(productKeyInfo);
                if (ValidateProductKeyInfo(productKeyInfo).ResultStatus)
                {
                    CryptInfo cryptInfo = new CryptInfo();
                    cryptInfo.CryptKey = cryptKey;
                    cryptInfo.ValueToCrypt = productKey;
                    var securityFactory = new SecurityFactory();
                    productKeyInfo.EncryptedProductKey = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);

                    return productKeyInfo.EncryptedProductKey;
                }
                else
                {
                    productKeyInfo.ErrorMessage.Append("Encryption failed");
                    return productKeyInfo.EncryptedProductKey = string.Empty;
                }
            }
            catch (Exception ex)
            {
                productKeyInfo.ErrorMessage.Append(ex.Message);
                return productKeyInfo.EncryptedProductKey =string.Empty;
            }
        }

        private  LicenseInfo DecryptProductKey(string encryptedProductKey)
        {
            LicenseInfo productKeyInfo = new LicenseInfo();
            try
            {
                
                productKeyInfo.ErrorMessage = new StringBuilder();
                if (string.IsNullOrEmpty(encryptedProductKey))
                {
                    productKeyInfo.ErrorMessage.Append("Encrypted product key not found!...");
                    productKeyInfo.ResultStatus = false;
                    return productKeyInfo;
                }
                CryptInfo cryptInfo = new CryptInfo();
                cryptInfo.CryptKey = cryptKey;
                cryptInfo.ValueToCrypt = encryptedProductKey;
                var securityFactory = new SecurityFactory();
                string productKey = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);

                var productKeyInformation = productKey.Split('|');
                productKeyInfo.ToolPurchased = productKeyInformation[0];
                productKeyInfo.DateOfPurchase = productKeyInformation[1];
                productKeyInfo.Version = productKeyInformation[2];
                productKeyInfo.InstanceID = productKeyInformation[3];
                productKeyInfo.UserCount = Convert.ToInt16(productKeyInformation[4]);
                productKeyInfo.ResultStatus = true;
                return productKeyInfo;
                
            }
            catch (Exception ex)
            {
                productKeyInfo.ErrorMessage.Append(ex.Message);
                productKeyInfo.ResultStatus = false;
                return productKeyInfo;
               
               
            }
        }
        public override bool ValidateProductLicenseKey(string encryptedProductKey)
        {
            LicenseInfo productKeyInfo = new LicenseInfo();
            
           productKeyInfo= DecryptProductKey(encryptedProductKey);
           DateTime PurchasedDate = Convert.ToDateTime(productKeyInfo.DateOfPurchase).Date;
           if (PurchasedDate.AddYears(1) < System.DateTime.Now)
           {
               productKeyInfo.ErrorMessage.Append("Expired Product License Key");
               productKeyInfo.ResultStatus = false;
               return false;
           }
           else if (PurchasedDate.AddYears(1).AddDays(-7) <  System.DateTime.Now)
           {
               productKeyInfo.ErrorMessage.Append("Product License Key will expirse in a week");
               productKeyInfo.ResultStatus = false;
               return false;
           }
           // if(productKeyInfo.UserCount>500)
           //{
           //    productKeyInfo.ErrorMessage.Append("User Count exceeds the maximum value");
           //    productKeyInfo.ResultStatus = false;
           //    return false;
           //}
           else
               return true;
            
        }
        


    }
}
