﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public struct S_CryptTypes
    {
        public const string AES = "AES";
        public const string SHA = "SHA";
        public const string RSA = "RSA";
        public const string Base64 = "Base64";
    }

    public struct S_SourceTypes
    {
        public const string DB = "DB";
        public const string AD = "AD";
    }
}
