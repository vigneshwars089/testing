﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
     public interface IUserSecurity
    {
        bool Authenticate(UserContextInfo objUserContextInfo);
        bool Authorize(UserRoleInfo objUserRoleInfo);
        bool UserTimeStampCheck(string jsonWebToken, string secretKey, UserContextInfo userContextInfo);
       
    }
}
