﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{

    public struct S_AppID
    {
        public const string EMT = "EMT";
        public const string AUDIT = "AUDIT";
        public const string PRODUCTION = "PRODUCTION";
      
    }
    [Serializable]
    public class UserInfo : BaseInfo
    {

        public string UserID { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public string EmailID { set; get; }
        public string EncryptPassword { set; get; }
        public string EncryptConfirmPassword { set; get; }
        public string TimeZone { set; get; }
        public bool IsActive { set; get; }
        public string UserManagingType { set; get; }
        public string LoginType { set; get; }
        public int RoleId { set; get; }
        public string UTCTime { set; get; }
    }   

}
