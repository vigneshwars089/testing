﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{      
     [Serializable]
    public class RoleInfo : BaseInfo
    {
        public string UserID { set; get; }
        public string LoginId { set; get; }
        public int RoleId { set; get; }
        public string CountryId { set; get; }
        public string UserRoleMapId { get; set; }
    }
}
