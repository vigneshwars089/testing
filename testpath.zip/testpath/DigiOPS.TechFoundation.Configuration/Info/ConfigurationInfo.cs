﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Configuration
{
    public class ConfigurationInfo : BaseInfo
    {
    }
    public struct S_ConfigurationType
    {
        public const string DynamicField = "DynamicField";
        public const string ApplicationSettings = "ApplicationSettings";
        public const string ProductionSettings = "ProductionSettings";
        public const string AuditSettings = "AuditSettings";
    }
}
