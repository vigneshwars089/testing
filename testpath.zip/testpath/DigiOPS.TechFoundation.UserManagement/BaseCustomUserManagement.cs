﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.UserManagement
{
    public class BaseCustomUserManagement : ICustomUserManagement
    {

        public virtual int CreateUser(UserInfo BaseData)
        {
            int result=0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                    case S_AppID.EMT:
                        {
                            if (ValidatingUser(BaseData))
                            {
                                IUserRepository objUserRepository = new EMTUserRepository();

                                result= objUserRepository.Create(BaseData);
                                if (result <= 0)
                                {
                                    BaseData.ErrorMessage.Append("Error");
                                    return result;
                                }
                                else
                                {
                                    BaseData.ResultStatus = true;
                                    return result;
                                }
                            }
                            break;
                        }
                    default: { break;  }
                } 
            }
            catch (Exception Ex)
            {
                BaseData.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        public virtual int UpdateUser(UserInfo BaseData)
        {
            int result = 0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                    case S_AppID.EMT:
                        {
                            if (ValidatingUser(BaseData))
                            {
                                IUserRepository objUserRepository = new EMTUserRepository();

                                result = objUserRepository.Update(BaseData);
                                if (result <= 0)
                                {
                                    BaseData.ErrorMessage.Append("Error");
                                    return result;
                                }
                                else
                                {
                                    BaseData.ResultStatus = true;
                                    return result;
                                }
                            }
                            break;
                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                BaseData.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        public virtual int AssignUserRole(RoleInfo ObjRoleInfo)
        {
            int result = 0;
            ObjRoleInfo.ResultStatus = false;
            try
            {
                switch (ObjRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.AssignRole(ObjRoleInfo);
                            if (result <= 0)
                            {
                                ObjRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                ObjRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                ObjRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        public int UpdateUserRole(RoleInfo objRoleInfo)
        {
            int result = 0;
            objRoleInfo.ResultStatus = false;
            try
            {
                switch (objRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.UpdateUserRole(objRoleInfo);
                            if (result <= 0)
                            {
                                objRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                objRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        private bool IsValidRoleToAccessThisPage(UserInfo UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.TeamLead) || (UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    //Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                    return false;
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
                //Response.Redirect("~/Errors/Error.aspx", false);
                return false;
            }

        }

   
        public bool ValidatingUser(UserInfo BaseData)
        {
            if (string.IsNullOrEmpty(BaseData.UserID))
            {
                BaseData.ErrorMessage.Append("UserID is null"); 
            }
            else if (string.IsNullOrEmpty(BaseData.FirstName))
            { 
                BaseData.ErrorMessage.Append("FirstName is null");
            }
            else if (string.IsNullOrEmpty(BaseData.LastName))
            {
                BaseData.ErrorMessage.Append("LastName is null");
            }
            else if (string.IsNullOrEmpty(BaseData.EmailID))
            { 
                BaseData.ErrorMessage.Append("EmailID is null"); 
            }
            else if (string.IsNullOrEmpty(BaseData.TimeZone))
            {
                BaseData.ErrorMessage.Append("TimeZone is null");
            }
            else if (string.IsNullOrEmpty(BaseData.EncryptPassword))
            { 
                BaseData.ErrorMessage.Append("EncryptPassword is null"); 
            }
            else if (string.IsNullOrEmpty(BaseData.EncryptConfirmPassword))
            { 
                BaseData.ErrorMessage.Append("EncryptConfirmPassword is null"); 
            }
            else if (BaseData.EncryptPassword != BaseData.EncryptConfirmPassword)
            {
                BaseData.ErrorMessage.Append("Password's do not match");
                return false;
            }
            else
            {
                return true;
            }

            return false;

        }




        public int DeleteUserRole(RoleInfo objRoleInfo)
        {
            int result = 0;
            objRoleInfo.ResultStatus = false;
            try
            {
                switch (objRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.DeleteUserRole(objRoleInfo);
                            if (result <= 0)
                            {
                                objRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                objRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }
    }
}
