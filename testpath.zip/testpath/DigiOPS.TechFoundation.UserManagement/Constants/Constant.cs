﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.UserManagement
{

    public static class Constant
    {
        public enum UserRole
        {
            SuperAdmin = 1,
            Admin = 2,
            TeamLead = 3,
            Processor = 4,
            ClientUser = 5
        }

    }
}
