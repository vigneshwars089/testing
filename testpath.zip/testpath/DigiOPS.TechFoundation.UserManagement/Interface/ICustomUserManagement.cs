﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.UserManagement
{
   public interface ICustomUserManagement
    {
       int CreateUser(UserInfo objUserInfo);
       int UpdateUser(UserInfo objUserInfo);
       int AssignUserRole(RoleInfo objRoleInfo);       
       int UpdateUserRole(RoleInfo objUserInfo);
       int DeleteUserRole(RoleInfo objUserInfo);
    }
}
