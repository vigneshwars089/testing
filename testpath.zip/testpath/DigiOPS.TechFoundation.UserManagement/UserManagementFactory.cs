﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.UserManagement
{
   public class UserManagementFactory : IUserManagementFactory
    {
       public ICustomUserManagement GetUserManagementHandler(string usermanagementType)
        {
            if (usermanagementType == "User")
                return new BaseCustomUserManagement();
               

           //    else if(usermanagementType="Role")
           //else if(usermanagementType="Role Mapping")

            //switch (usermanagementType)
            //{
            //    case S_UserManagementType.User:
            //        return new CRUDUser(UserManagementInfo );

            //    default:
                    return null;
            //}
        }
    }
}
